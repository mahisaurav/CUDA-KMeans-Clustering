# Tesla T4 execution evidence

This local archive contains the benchmark, comparison, GPU centroids, and input hashes transcribed from the packaged implementation's Google Colab run on November 25, 2026. The execution log excerpt condenses the hardware banner. The performance chart was regenerated from the recorded benchmark. The clustering chart uses the checksum-verified input, CPU assignments that the GPU comparison found identical, and the exported GPU centroids.

The [Colab export cell](https://colab.research.google.com/drive/1eMnFl4r6BqDLR2u3q4oV8Bm4hEN_vjQB#scrollTo=o3U32bDPuT-H) also contains the full runtime archive. Its SHA-256 is `7937cdb2ba0ad1a9fd2b25e6f514b4ec85c2d64c5f362a33d9a1083094de1ef7`. This local ZIP packages the exported evidence because the in-app browser did not return the original file.

The evidence also includes the checksum-verified 10,000-point input and the local CPU assignment CSV. The Colab comparison confirmed identical GPU labels for that input.
